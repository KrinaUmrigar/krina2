const API_URL = 'http://localhost:3000';

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
    });

    if (response.ok) {
        const { token } = await response.json();
        localStorage.setItem('token', token);
        window.location.href = 'dashboard.html';
    } else {
        const { message } = await response.json();
        document.getElementById('loginError').textContent = message;
    }
});

document.getElementById('logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    window.location.href = 'index.html';
});

document.getElementById('addStudentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('studentEmail').value;
    const age = document.getElementById('age').value;
    const password = document.getElementById('studentPassword').value;

    const token = localStorage.getItem('token');

    await fetch(`${API_URL}/students`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name, email, age, password }),
    });

    loadStudents();
});

async function loadStudents() {
    const token = localStorage.getItem('token');

    const response = await fetch(`${API_URL}/students`, {
        headers: { 'Authorization': `Bearer ${token}` }
    });

    const students = await response.json();
    const studentList = document.getElementById('studentList');
    studentList.innerHTML = '';
    students.forEach(student => {
        const li = document.createElement('li');
        li.textContent = `${student.name} - ${student.email} - ${student.age}`;
        studentList.appendChild(li);
    });
}

if (localStorage.getItem('token')) {
    loadStudents();
}
