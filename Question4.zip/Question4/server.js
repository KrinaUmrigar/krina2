const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
// const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const Student = require('./models/Student'); 
const studentRoutes = require('./routes/students'); 

const cookieParser = require('cookie-parser');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('MongoDB connected');
}).catch(err => {
    console.error('MongoDB connection error:', err);
});

app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(cookieParser()); 
app.use('/students', studentRoutes);


const authenticateToken = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};


app.get('/', (req, res) => {
    res.render('login', { error: null });
});
// app.get('/register', (req, res) => {
//     res.render('register.ejs', { error: null });
// });
// app.post('/studentregister', async (req, res) => {
//     const { name, email, password } = req.body;
//     const hashedPassword = await bcrypt.hash(password, 10);
    
//     const student = new Student({ name, email, password: hashedPassword }); 
//     await student.save();
    
//     res.redirect('/');
// });

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const student = await Student.findOne({ email });

    if (student && student.password === password) {
        const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET);
        res.cookie('token', token, { httpOnly: true });
        return res.redirect('/dashboard');
    }

    res.render('login', { error: 'Invalid credentials' });
});

app.get('/dashboard', authenticateToken, async (req, res) => {
    const student = await Student.findById(req.user.id); 

    if (student) {
        res.render('dashboard', { user: student });
    } else {
        res.redirect('/login');
    }
});


app.get('/logout', (req, res) => {
    res.clearCookie('token');
    res.redirect('/');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
